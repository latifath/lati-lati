<?php

return [
    'next'     => 'Suivant &raquo;',
    'previous' => '&laquo; Précédent',
];
