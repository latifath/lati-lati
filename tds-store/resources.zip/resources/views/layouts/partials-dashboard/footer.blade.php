<footer class="footer" style="{{ couleur_principal() }}">
    <p class="text-gray-400"> &copy; {{ date('Y') }} Copyright
        &middot;<span>TDSstore</span></p>
    </div></footer>
