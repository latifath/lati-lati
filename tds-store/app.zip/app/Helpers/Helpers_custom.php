<?php


if(!function_exists('couleur_text_1')) {
    function couleur_text_1() {
         return "color :  #01674e";
    }
}

if(!function_exists('couleur_background_1')) {
    function couleur_background_1() {
         return "background-color :  #01674e";
    }
}

if(!function_exists('couleur_text_2')) {
    function couleur_text_2() {
         return "color :  #ea0513";
    }
}

if(!function_exists('couleur_background_2')) {
    function couleur_background_2() {
         return "background-color :  #ea0513";
    }
}

if(!function_exists('couleur_text_3')){
    function couleur_text_3(){
        return "color: #1C1C1C";
    }
}

if(!function_exists('couleur_principal')){
    function couleur_principal(){
        return "background-color: #EDF1FF";
    }
}

if(!function_exists('couleur_blanche')){
    function couleur_blanche(){
        return "color: #ffff";
    }
}
